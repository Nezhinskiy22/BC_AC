// $(document).ready(function() {
//     //------------------1st task - border colour pink----------------------
//     $(".product-item__badge").parent().css({ "border": "1px solid pink" });
//     //------------------2nd task - odd blue background---------------------
//     $(".filters__size-swatch:even").css({ "background": "blue" });
//     //------------------3rd task - clone 2 tiles---------------------------
//     $(".product-item:nth-last-child(-n+2)").clone().appendTo('.product-list');
//     //------------------4th task - remove "Occasion"-----------------------
//     $(".filters__list span:contains(Occasion)").parent().remove()
// });

let basket = document.querySelector(".product-basket__table");
let addButton = document.querySelectorAll(".product-item__add-btn");
let productNames = document.querySelectorAll(".product-item__name");
let productPrices = document.querySelectorAll(".product-item__price");
let itemNum = 0;

addButton.forEach(function(elem, i) {
    elem.addEventListener("click", function(e) {
        let uniquId = Math.floor(100000 + Math.random() * 9000);
        let itemName = productNames[i].textContent
        let itemPrice = productPrices[i].textContent;
        itemNum++
        let child = `<tr>
        <td data=${uniquId} class="basketNum">${itemNum}</td>
        <td>${itemName}</td>
        <td>${itemPrice}</td>
        <td class="item-remove">remove</td>
        </tr>`;
        basket.innerHTML += child;




        let removeBtn = document.querySelectorAll(".item-remove");
        removeBtn.forEach(function(item) {
            item.addEventListener("click", function(event) {
                event.target.parentNode.remove();
                recalculate();
            })
        })
    });
});


function recalculate() {
    let basketIndex = document.querySelectorAll(".basketNum")
    basketIndex.forEach(function(elem, i) {
        itemNum = basketIndex.length
        elem.textContent = i + 1

    })
}

function counter() {

}



// ??????????checked itemNum before sending????????????